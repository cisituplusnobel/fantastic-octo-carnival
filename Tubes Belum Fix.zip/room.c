/* Kelompok    : CisituPlusNobel
/* File        : room.c */
/* Tanggal     : 29 Oktober 2018 */

#include "room.h"
#include <stdio.h>

static FILE * pita;

void MakeEmptyTable(ROOM *R, TabInt *tables, int table)
/*  Membuat meja menjadi kosong. Meja kosong ditandai dengan X. Procedure ini hanya merubah
    tampilan pada matriks saja.*/
{
  // KAMUS LOKAL
  int ruang;
  int x,y;

  //ALGORITMA
  table--;
  ruang = (table/4)+1;
  table++;
  x = Absis(ElmtArray(*tables,table).PTable);
  y = Ordinat(ElmtArray(*tables,table).PTable);

  if (ElmtArray(*tables,table).Kapasitas == 4){
    ElmtMATRIKS(Elm(*R,ruang),x,y+1) = 'X';
    ElmtMATRIKS(Elm(*R,ruang),x,y-1) = 'X';
    ElmtMATRIKS(Elm(*R,ruang),x+1,y) = 'X';
    ElmtMATRIKS(Elm(*R,ruang),x-1,y) = 'X';
    ElmtMATRIKS(Elm(*R,ruang),x,y) = no[table];
  } else{
    ElmtMATRIKS(Elm(*R,ruang),x,y+1) = 'X';
    ElmtMATRIKS(Elm(*R,ruang),x,y-1) = 'X';
    ElmtMATRIKS(Elm(*R,ruang),x,y) = no[table];
  }
  ElmtArray(*tables,table).IsKosong = true;
  ElmtArray(*tables,table).Pesanan = DataUndef;
  ElmtArray(*tables,table).WaitTime = DataUndef;
}

void MakeFullTable(ROOM *R, TabInt *tables, int table, Customer X, int num)
/*  Membuat meja yang kapasitasnya 4 menjadi penuh. Meja penuh ditandai dengan C. Procedure 
    ini hanya merubah tampilan pada matriks saja.*/
{
  // KAMUS LOKAL
  int ruang;
  int x,y;

  //ALGORITMA
  table--;
  ruang = (table/4)+1;
  table++;
  x = Absis(ElmtArray(*tables,table).PTable);
  y = Ordinat(ElmtArray(*tables,table).PTable);

  if (num == 4){
    ElmtMATRIKS(Elm(*R,ruang),x,y+1) = 'C';
    ElmtMATRIKS(Elm(*R,ruang),x,y-1) = 'C';
    ElmtMATRIKS(Elm(*R,ruang),x+1,y) = 'C';
    ElmtMATRIKS(Elm(*R,ruang),x-1,y) = 'C';
  } else{
    if (ElmtArray(*tables,table).Kapasitas == 4){
      ElmtMATRIKS(Elm(*R,ruang),x,y+1) = 'C';
      ElmtMATRIKS(Elm(*R,ruang),x,y-1) = 'C';
      ElmtMATRIKS(Elm(*R,ruang),x+1,y) = 'X';
      ElmtMATRIKS(Elm(*R,ruang),x-1,y) = 'X';
    } else{
      ElmtMATRIKS(Elm(*R,ruang),x,y+1) = 'C';
      ElmtMATRIKS(Elm(*R,ruang),x,y-1) = 'C';
    }
  }
  ElmtArray(*tables,table).Pesanan = X.Pesanan;
  ElmtArray(*tables,table).WaitTime = 90;
  ElmtArray(*tables,table).IsKosong = false;
}

void MakeKitchen(ROOM *R, TabInt kitchen, POINT N)
/*  Membuat bentuk denah kitchen. Setiap tempat bahan makanan ditandai dengan M dan nampan ditandai
    dengan T */
{
  //KAMUS LOKAL
  int i,x,y;

  //ALGORITMA
  //printf("%d\n", NbElmtArray(kitchen));
  for (i=1; i<=NbElmtArray(kitchen); i++){
    x = Absis(ElmtArray(kitchen,i).PTable);
    y = Ordinat(ElmtArray(kitchen,i).PTable);
    ElmtMATRIKS(Elm(*R,4),x,y) = 'M';
  }
  ElmtMATRIKS(Elm(*R,4),Absis(N), Ordinat(N)) = 'T';
}

void CekKosong4(TabInt tables, int *table)
/*  Melakukan pengecekan apakah terdapat meja dengan kapasitas 4 yang kosong. Pengeekan masih
    dilakukan primitif karena hanya meihat isi matriksnya saja (X atau C). Jika terdapat meja
    dengan kapasitas 4 yang kosong, maka room dan table akan diisi dengan ruangan dan nomor meja
    ditemukannya meja kosong. Jika tidak room dan table akan diisi dengan -999 */
{
  //KAMUS LOKAL
  int i;
  boolean kosong;

  //ALGORITMA
  i=1;
  kosong = false;
  *table = -999;
  while (i<=12 && !kosong){
    if (ElmtArray(tables,i).IsKosong && ElmtArray(tables,i).Kapasitas == 4){
      kosong = true;
      *table = i;
    } else{
      i++;
    }
  }
}

void CekKosong2(TabInt tables, int *table)
/*  Melakukan pengecekan apakah terdapat meja dengan kapasitas 2 yang kosong. Pengeekan masih
    dilakukan primitif karena hanya meihat isi matriksnya saja (X atau C). Jika terdapat meja
    dengan kapasitas 2 yang kosong, maka room dan table akan diisi dengan ruangan dan nomor meja
    ditemukannya meja kosong. Jika tidak room dan table akan diisi dengan -999 */
{
  //KAMUS LOKAL
  int i;
  boolean kosong;

  //ALGORITMA
  i=1;
  while (i<=12 && !kosong){
    if (ElmtArray(tables,i).IsKosong && ElmtArray(tables,i).Kapasitas == 2){
      kosong = true;
      *table = i;
    } else{
      i++;
    }
  }
  i=1;
  while (i<=12 && !kosong){
    if (ElmtArray(tables,i).IsKosong && ElmtArray(tables,i).Kapasitas == 4){
      kosong = true;
      *table = i;
    } else{
      i++;
    }
  }
}

void CekSebelahan(int room, POINT P,int *table, TabInt tables)
/*  Melakukan oengecekan apakah koordinat player (P) bersebelahan dengan salah satu meja
    Jika bersebelahan maka akan meja akan diisi dengan nomor meja yang bersebelahan*/
{
  //KAMUS LOKAL
  int x,y;
  int i;

  //ALGORITMA
  *table = -999;
  i = ((room-1)*4)+1;
  while (i <= ((room-1)*4)+4 && *table==-999){
    //printf("Untuk i = %d\n",i);
    x = Absis(ElmtArray(tables,i).PTable);
    y = Ordinat(ElmtArray(tables,i).PTable);
    if (room != 4){
      if ((Ordinat(P)==y+1) || (Ordinat(P)==y-1)){
        if ((Absis(P)==(x-1)) || (Absis(P)==(x+1)) || (Absis(P)==(1))){
          *table = i;
        }
      }
    }
    //printf("x=%d y=%d\n", x,y);
    //printf("Px=%d Py=%d\n", Absis(P),Ordinat(P));
    i++;
  }
  //printf("table=%d\n",*table);
}

void CekSebelahanDapur(TabInt kitchen, POINT P, int *X)
/**/
{
  //KAMUS LOKAL
  int i;
  int x,y;
  //ALGORITMA
  i = 1;
  *X = -999;
  while ((*X == -999) && i<=NbElmtArray(kitchen)){
    x = Absis(ElmtArray(kitchen,i).PTable);
    y = Ordinat(ElmtArray(kitchen,i).PTable);
    if (Absis(P) == x){
      if (Ordinat(P) == y+1 || Ordinat(P) == y-1){
        *X = i;
      }
    } else if (Ordinat(P) == y){
      if (Absis(P) == x+1 || Absis(P) == x-1){
        *X = i;
      }
    }
    i++;
  }
}

int chartoint (char a) {
  switch (a) {
    case '0' : return 0;
    case '1' : return 1;
    case '2' : return 2;
    case '3' : return 3;
    case '4' : return 4;
    case '5' : return 5;
    case '6' : return 6;
    case '7' : return 7;
    case '8' : return 8;
    case '9' : return 9;
  }
}

void LoadRoom (ROOM *R, TabInt *tables, TabInt *kitchen, POINT *N, StatusTable status)
/**/
{
  //KAMUS LOKAL
  int i, j, xp, yp, k;

  //ALGORITMA
  START("pitakar.txt");
  j = 1;
  for (i=1;i<=3;i++) {
    //printf("%d\n", chartoint(CC));
    Absis((*R).door1[i]) = chartoint(CC);
    ADV(); IgnoreBlank();
    Ordinat((*R).door1[i]) = chartoint(CC);
    ADV(); IgnoreBlank();
    (*R).dest1[i] = chartoint(CC);
    ADV(); IgnoreBlank();
    Absis((*R).door2[i]) = chartoint(CC);
    ADV(); IgnoreBlank();
    Ordinat((*R).door2[i]) = chartoint(CC);
    ADV(); IgnoreBlank();
    (*R).dest2[i] = chartoint(CC);
    ADV(); IgnoreBlank();
    // for (i=1;i<=12;i++){
    //   (*emptyOrder).NbTable = i;
    //   (*emptyOrder).Kapasitas = NPeople[i]; 
    //   (*emptyOrder).PTable = MakePOINT(PMeja[i]/10,PMeja[i]%10);
    //   AddEli(tables,(*emptyOrder),i);
    // }
    while (CC!=',') {
      status.NbTable = j;
      xp = chartoint(CC);
      Absis(status.PTable) = xp;
      ADV(); IgnoreBlank();
      //printf("%d ", xp);
      yp = chartoint(CC);
      Ordinat(status.PTable) = yp;
      ADV(); IgnoreBlank();
      //printf("%d ", yp);
      k = chartoint(CC);
      status.Kapasitas = k;
      AddEli(tables,status,j);
      ADV(); IgnoreBlank();
      j++;
      //printf("%d ", k);
    }
    ADV();ADV(); IgnoreBlank();
    status.Kapasitas = DataUndef;
    status.NbTable = DataUndef;
    status.PTable = MakePOINT(-999,-999);
  }
  i = 1;
  while (CC!='.') {
    //printf("%c ", CC);
    xp = chartoint(CC);
    Absis(status.PTable) = xp;
    ADV(); IgnoreBlank();
    //printf("%c ", CC);
    yp = chartoint(CC);
    Ordinat(status.PTable) = yp;
    ADV(); IgnoreBlank();
    k = chartoint(CC);
    ADV();
    if (CC != ' '){
      k = k*10 + chartoint(CC);
      status.Isi = k;
      AddEli(kitchen,status,i);
      ADV(); IgnoreBlank();
    }else{
      if (k!=0){
        AddEli(kitchen,status,i);
      }else{
        Absis(*N) = xp;
        Ordinat(*N) = yp;
      }
      ADV(); IgnoreBlank();
    }
    i++;
    //printf("%d\n", k);
  }
}

void Inisalisasi(int n, int *room, int *custs, ROOM *R, POINT *P, POINT *N, JAM *J, int *Add, Queue *Q, Stack *Hand, Stack *Food, TabInt *orders, TabInt *tables, TabInt *kitchen, StatusTable *status, int *life, int *money, BinTree *Resep)
/*  Melakukan inisalisasi pada bentuk setiap room yaitu ruangan dalam representasi matriks, koordinat pemain,
    waktu pemain, antrian, stack of foods, array of orders, list of tables */
{
  //KAMUS LOKAL
  int i,j,k;
  Customer cust;

  //ALGORITMA
  *room = 1;
  *custs = 0;

  for (i=1; i<=4; i++){
    MakeMATRIKS(8,8,&(Elm(*R,i)));
  }

  *P = MakePOINT(4,4);
  *J = MakeJAM(0,0,0);
  
  *Add = 5;
  
  CreateEmptyQueue(Q,10);
  if (n % 2 == 0){
    cust.NbPeople = 4;
  } else{
    cust.NbPeople = 2; 
  }
  cust.WaitTime = 40;
  cust.Pesanan = (n % 8) + 17;
  cust.star = false;

  AddQueue(Q, cust);
  (*custs)++;
  
  CreateEmptyStackt(Food);
  CreateEmptyStackt(Hand);
  
  (*status).WaitTime = DataUndef;
  (*status).NbTable = DataUndef;
  (*status).Kapasitas = DataUndef;
  (*status).Pesanan = DataUndef;
  (*status).PTable = MakePOINT(-999,-999);
  (*status).IsKosong = true;
  (*status).Isi = DataUndef;
  
  MakeEmpty(orders);
  // for (i=1;i<=12;i++){
  //   AddEli(orders,*emptyOrder,i);
  // }

  MakeEmpty(tables);
  MakeEmpty(kitchen);
  // for (i=1;i<=12;i++){
  //   (*emptyOrder).NbTable = i;
  //   (*emptyOrder).Kapasitas = NPeople[i]; 
  //   (*emptyOrder).PTable = MakePOINT(PMeja[i]/10,PMeja[i]%10);
  //   AddEli(tables,(*emptyOrder),i);
  // }
  LoadRoom(R,tables,kitchen,N,*status);
  // for (j=1; j<=12; j++){
  //   printf("%d %d\n", Absis(ElmtArray(*tables,j).PTable), Ordinat(ElmtArray(*tables,j).PTable));
  // }Room(R,tables,kitchen,*emptyOrder,N);

  // for (j=1; j<=12; j++){
  //   printf("%d %d\n", Absis(ElmtArray(*tables,j).PTable), Ordinat(ElmtArray(*tables,j).PTable));
  // }

  // (*emptyOrder).IsKosong = true; 
  // (*emptyOrder).Kapasitas = DataUndef;
  // (*emptyOrder).NbTable = DataUndef;
  // (*emptyOrder).PTable = MakePOINT(-999,-999);
  
  for (i=1; i<=4; i++){
    for (j=1; j<=8; j++){
      for (k=1; k<=8; k++){
        ElmtMATRIKS(Elm(*R,i),j,k) = ' ';
      }
    }
  }
  for (j=1; j<=12; j++){
    MakeEmptyTable(R,tables,j);
  }

  MakeKitchen(R, *kitchen, *N);

  *life = 3;
  
  *money = 0;

  LoadTree(Resep);
}