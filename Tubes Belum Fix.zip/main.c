#include <stdio.h>
#include <stdlib.h>
#include "matriks.h"
#include "point.h"
#include "jam.h"
#include "queue.h"
#include "stackt.h"
#include "array.h"
#include "room.h"
#include "function.h"
#include "boolean.h"
#include "mesinkata.h"
#include "mesinkar.h"
#include "pohonbiner.h"
#include "datatype.h"

#include <termios.h>
#include <unistd.h>

int getch(void)
{
	struct termios oldt, newt;
	int ch;

	tcgetattr(STDIN_FILENO, &oldt);
	newt = oldt;
	newt.c_lflag &= ~(ICANON | ECHO);
	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	ch = getchar();
	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);

	return ch;
}

int main(){
  //KAMUS LOKAL
  ROOM R;
  POINT P,N;
  BinTree Resep;
  JAM J;
  int Add,custs;
  Queue Q;
  Stack Hand,Food;
  char C;
  char command[12], name[20];
  int room, life, money, cmd;
  TabInt orders,tables,kitchen;
	StatusTable status;
  boolean EOProgram;

  //KAMUS CEKCOMMAND
  int i,j;
  boolean found,sama,start;

  int key;
  boolean move, input;

  //ALGORITMA
  start = false;
  name[0] = '\0';
  while (!start){
    system("clear");
    printf(" /$$$$$$$$                     /$$ /$$ /$$$$$$        /$$   /$$ /$$   /$$               /$$                          \n");
    printf("| $$_____/                    |__/| $//$$__  $$      | $$  /$$/|__/  | $$              | $$                          \n");
    printf("| $$       /$$$$$$$   /$$$$$$  /$$|_/| $$  `__/      | $$ /$$/  /$$ /$$$$$$    /$$$$$$$| $$$$$$$   /$$$$$$  /$$$$$$$ \n");
    printf("| $$$$$   | $$__  $$ /$$__  $$| $$   |  $$$$$$       | $$$$$/  | $$|_  $$_/   /$$_____/| $$__  $$ /$$__  $$| $$__  $$\n");
    printf("| $$__/   | $$  ` $$| $$  ` $$| $$    `____  $$      | $$  $$  | $$  | $$    | $$      | $$  ` $$| $$$$$$$$| $$  ` $$\n");
    printf("| $$      | $$  | $$| $$  | $$| $$    /$$  ` $$      | $$`  $$ | $$  | $$ /$$| $$      | $$  | $$| $$_____/| $$  | $$\n");
    printf("| $$$$$$$$| $$  | $$|  $$$$$$$| $$   |  $$$$$$/      | $$ `  $$| $$  |  $$$$/|  $$$$$$$| $$  | $$|  $$$$$$$| $$  | $$\n");
    printf("|________/|__/  |__/ `____  $$|__/    `______/       |__/  `__/|__/   `___/   `_______/|__/  |__/ `_______/|__/  |__/\n");
    printf("                     /$$  ` $$                                                                                       \n");
    printf("                    |  $$$$$$/                  __ __ __(_)| |_ | |_    ___ __ __ _ __  __ _  _ _   ___(_) ___  _ _  \n");
    printf("                     `______/                   ` V  V /| ||  _|| ' `  / -_)` ` /| '_ `/ _` || ' ` (_-<| |/ _ `| ' ` \n");
    printf("                                                 `_/`_/ |_| `__||_||_| `___|/_`_`| .__/`__,_||_||_|/__/|_|`___/|_||_|\n");
    printf("                                                                                 |_|                                 \n");
    printf("\n");
    if (name[0] != '\0'){
      printf("Selamat Datang %s!\n", name);
    } else{
      printf("\n");
    }
    printf("╔╦╗╔═╗╦╔╗╔  ╔╦╗╔═╗╔╗╔╦ ╦\n");
    printf("║║║╠═╣║║║║  ║║║║╣ ║║║║ ║\n");
    printf("╩ ╩╩ ╩╩╝╚╝  ╩ ╩╚═╝╝╚╝╚═╝\n");
    printf(">> START\n");
    printf(">> NEW\n");
    printf(">> LOAD\n");
    printf(">> EXIT\n");
    printf("COMMAND : ");
    scanf("%s", command);
    scanf("%c", &C);
    STARTKATA();
    i = 1;
    found = false;
    while (!found && i<=4){
      sama = true;
      j = 1;
      while (j<=CKata.Length && sama){
        if (CKata.TabKata[j] == command[j-1]){
          j++;
        } else{
          sama = false;
        }
      }
      if (sama){
        found = true;
      } else{
        i++;
        ADVKATA();
      }
    }
    if (!found){
      i = DataUndef;
    }
    switch (i){
      case 1:
        if (name[0] != '\0'){
          start = true;
        } else{
          printf("Silahkan Pilih New Game Atau Load Game Terlebih Dahulu");
          scanf("%c", &C);
        }
        break;
      case 2:
        printf("Enter Your Name : ");
        scanf("%s", name);
        break;
      default:
        printf("Masukan Salah!");
        scanf("%c", &C);
    }
  }
  
  if (start){
    Inisalisasi(name[0], &room, &custs, &R, &P, &N, &J, &Add, &Q, &Hand, &Food, &orders, &tables, &kitchen, &status, &life, &money, &Resep);
  }
  ElmtMATRIKS(Elm(R,1),Absis(P),Ordinat(P)) = 'P';
  EOProgram = false;
  move = true;
  input = false;
  system("clear");
  Interface(name, R, room, Q, Hand, Food, orders, J, life, money);
  while(life<5 && !EOProgram){
    if (move){
      while (move){
        key = getch();
        if (key == 87){
          Go(&R,&P, 'U', &room);
        } else if (key == 65){
          Go(&R,&P, 'L', &room);
        } else if (key == 83){
          Go(&R,&P, 'D', &room);
        } else if (key == 68){
          Go(&R,&P, 'R', &room);
        } else if (key == 69){
          move = false;
          input = true;
          J = PrevDetik(J);
        } else{
          printf("Masukan Salah!\n");
          J = PrevDetik(J);
        }
        J = NextDetik(J);
        system("clear");
        AddRemove(&orders, &Q, J, &R, P, &life, &tables, &Add, money, &custs);
        Interface(name, R, room, Q, Hand, Food, orders, J, life, money);
      }
    } else if (input){
      while (input){
        printf("COMMAND = \n>> ");
        scanf("%s", command);
        //ALGORITMA CEK COMMAND
        STARTKATA();
        i = 1;
        found = false;
        while (!found && !EndKata){
          sama = true;
          j = 1;
          while (j<=CKata.Length && sama){
            if (CKata.TabKata[j] == command[j-1]){
              j++;
            } else{
              sama = false;
            }
          }
          if (sama){
            found = true;
          } else{
            i++;
            ADVKATA();
          }
        }
        i = i-4;
        if (!found){
          i = DataUndef;
        }
        //AKHIR AlGORITMA CEK COMMAND 

        switch (i){
          case 1: //GD
            Go(&R,&P, 'D', &room);
            break;
          case 2: //GU
            Go(&R,&P, 'U', &room);
            break;
          case 3: //GL
            Go(&R,&P, 'L', &room);
            break;
          case 4: //GR
            Go(&R,&P, 'R', &room);
            break;
          case 5: //ORDER
            Order(room, P, &orders, &tables);
            break;
          case 6: //PUT
            Put(Resep, &Hand, &Food, P, N);
            break;
          case 7: //TAKE
            Take(P, &Hand, room, kitchen);
            break;
          case 8: //CAH
            CAH(&Hand);
            break;
          case 9: //COH
            COH(&Hand);
            break;
          case 10: //CAT
            CAH(&Food);
            break;
          case 11: //COT
            COH(&Food);
            break;
          case 12: //PLACE
            Place(&Q, &R, P, room, &tables);
            break;
          case 13: //GIVE
            Give(room, &Food, &R, P, &tables, &orders, &money);
            break;
          case 14: //RECIPE
            Recipe(Resep);
            J = PrevDetik(J);
            break;
          case 15: //MOVE
            move = true;
            input = false;
            J = PrevDetik(J);
            break;
          case 0:
            EOProgram = true;
            break;
          default :
            printf("Perintah Yang Dimasukkan Salah!");
            scanf("%c", &C);
            J = PrevDetik(J);
            break;
        }
        J = NextDetik(J);
        system("clear");
        AddRemove(&orders, &Q, J, &R, P, &life, &tables, &Add, money, &custs);
        Interface(name, R, room, Q, Hand, Food, orders, J, life, money);
      }
    }
  }
  if (life==0){
    system("clear");
    Interface(name, R, room, Q, Hand, Food, orders, J, life, money);
    printf("GAME BERAKHIR\n");
  }
  return 0;
}

// gcc main.c point.c queue.c stackt.c array.c matriks.c jam.c function.c datatype.c room.c pohonbiner.c mesinkar.c mesinkata.c -o main