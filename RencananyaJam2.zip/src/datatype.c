/* Kelompok    : CisituPlusNobel
/* File        : datatype.c */
/* Tanggal     : 29 Oktober 2018 */


#include "../include/datatype.h"

char bahan[25][20] = {
    "",
	"Piring",
    "Sendok",
    "Garpu",
	"Es Krim",
	"Nasi",
	"Roti",
	"Spaghetti",
	"Pisang",
	"Stroberi",
	"Telur",
	"Ayam Goreng",
	"Patty",
	"Sosis",
	"Bolognese",
	"Carbonara",
	"Keju",
	"Banana Split",
    "Sundae",
    "Nasi Telur Dadar",
	"Nasi Ayam Goreng",
	"Burger",
	"Hot Dog",
	"Spaghetti Bolognese",
	"Spaghetti Carbonara"
};

int harga[9] = {
    0,13,10,15,20,18,18,25,20
};

char no[13] = {
	' ','1','2','3','4','5','6','7','8','9','P','Q','R'
};