#include <stdio.h>
#include <stdlib.h>
#include "matriks.h"
#include "point.h"
#include "jam.h"
#include "queue.h"
#include "stackt.h"
#include "array.h"
#include "room.h"
#include "function.h"
#include "boolean.h"
#include "mesinkata.h"
#include "mesinkar.h"
#include "pohonbiner.h"
#include "datatype.h"
#include "menu.h"

int main(){
  //KAMUS LOKAL
  ROOM R;
  POINT P,N;
  BinTree Resep;
  JAM J;
  int Add,custs, room, life, money, cmd;
  Queue Q;
  Stack Hand,Food;
  char command[12], name[20];
  char C;
  TabInt orders,tables,kitchen;
	StatusTable status;
  boolean EOProgram, tick, load, new;
  int key;
  boolean move, input;

  //ALGORITMA
  menu(name,&new,&load);
  printf("%s %d %d\n", name, new, load);
  if (new){
    printf("KESINI\n");
    Inisialisasi(name[0], &room, &custs, &R, &P, &N, &J, &Add, &Q, &Hand, &Food, &orders, &tables, &kitchen, &status, &life, &money, &Resep);
    EOProgram = false;
  } else if (load){
    EOProgram = false;
    LoadGame(name, &room, &custs, &R, &P, &N, &J, &Add, &Q, &Hand, &Food, &orders, &tables, &kitchen, &status, &life, &money, &Resep);
  }
  ElmtMATRIKS(Elm(R,room),Absis(P),Ordinat(P)) = 'P';
  
  move = true;
  input = false;
  EOProgram = false;
  system("clear");
  Interface(name, R, room, Q, Hand, Food, orders, J, life, money);
  while(life>0 && (EOProgram == false)){
    if (move){
      while (move){
        tick = true;
        key = getch();
        if (key == 87){
          Go(&R,&P, 'U', &room);
        } else if (key == 65){
          Go(&R,&P, 'L', &room);
        } else if (key == 83){
          Go(&R,&P, 'D', &room);
        } else if (key == 68){
          Go(&R,&P, 'R', &room);
        } else if (key == 69){
          move = false;
          input = true;
          tick = false;
        } else{
          tick = false;
          printf("Masukan Salah!\n");
        }
        if (tick){
          J = NextDetik(J);
          AddRemove(&orders, &Q, J, &R, P, &life, &tables, &Add, money, &custs);
        }
        system("clear");
        Interface(name, R, room, Q, Hand, Food, orders, J, life, money);
        if (life == 0){
          EOProgram = true;
          move = false;
        }
      }
    } else if (input){
      while (input){
        tick = true;
        printf("COMMAND = \n>> ");
        scanf("%s", command);
        CekCommand(&cmd, command);
        switch (cmd){
          case 1: //GD
            Go(&R,&P, 'D', &room);
            break;
          case 2: //GU
            Go(&R,&P, 'U', &room);
            break;
          case 3: //GL
            Go(&R,&P, 'L', &room);
            break;
          case 4: //GR
            Go(&R,&P, 'R', &room);
            break;
          case 5: //ORDER
            Order(room, P, &orders, &tables);
            break;
          case 6: //PUT
            Put(Resep, &Hand, &Food, P, N);
            break;
          case 7: //TAKE
            Take(P, &Hand, room, kitchen);
            break;
          case 8: //CAH
            CAH(&Hand);
            break;
          case 9: //COH
            COH(&Hand);
            break;
          case 10: //CAT
            CAH(&Food);
            break;
          case 11: //COT
            COH(&Food);
            break;
          case 12: //PLACE
            Place(&Q, &R, P, room, &tables);
            break;
          case 13: //GIVE
            Give(room, &Food, &R, P, &tables, &orders, &money);
            break;
          case 14: //RECIPE
            Recipe(Resep);
            tick = false;
            break;
          case 15: //SAVE
            SaveGame(name,room,custs,P,N,J,Add,Q,Hand,Food,orders,tables,kitchen,life,money);
            tick = false;
            break;
          case 16: //MOVE
            move = true;
            input = false;
            tick = false;
            break;
          case 0:
            EOProgram = true;
            input = false;
            tick = false;
            break;
          default :
            printf("Perintah Yang Dimasukkan Salah!");
            scanf("%c", &C);
            tick = false;
            break;
        }
        if (tick){
          J = NextDetik(J);
          AddRemove(&orders, &Q, J, &R, P, &life, &tables, &Add, money, &custs);
        }
        if (life == 0){
          EOProgram = true;
          input = false;
        }
        if (!EOProgram){
          system("clear");
          Interface(name, R, room, Q, Hand, Food, orders, J, life, money);
        }
      }
    }
  }
  if (life==0){
    system("clear");
    Interface(name, R, room, Q, Hand, Food, orders, J, life, money);
    printf("GAME BERAKHIR\n");
  }
  return 0;
}

// gcc main.c point.c queue.c stackt.c array.c matriks.c jam.c function.c datatype.c room.c pohonbiner.c mesinkar.c mesinkata.c -o main