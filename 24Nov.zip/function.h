/* Kelompok    : CisituPlusNobel
/* File        : function.h */
/* Tanggal     : 29 Oktober 2018 */

#include "datatype.h"
#include "point.h"
#include "jam.h"
#include "queue.h"
#include "stackt.h"
#include "array.h"
#include "boolean.h"
#include "room.h"
#include "mesinkata.h"
#include "mesinkar.h"
#include "pohonbiner.h"

void Interface(char* name, ROOM R, int room, Queue Q, Stack Hand, Stack Food, TabInt orders, JAM J, int life, int money);
/* Menulis Interface*/

void Go(ROOM *R, POINT *P, char C, int *room);
/*  Procesure Go terdiri dari 4 perintah yaitu Go Up, Go Down, Go Left, Go Right */

void Place(Queue *Q, ROOM *R, POINT P, int room, TabInt *tables);
/* Menempatkan pelangan dengan Top of Queue ke dalam meja yang kososng */

void Take(POINT P, Stack *S, int room, TabInt kitchen);
/*Mengambil bahan makanan di dekat player */

void CAH(Stack *S);
/* Membuang semua bahan makanan yang ada di tangan */

void COH(Stack *S);
/* Membuang satu bahan makanan yang ada di tangan */

void CAT(Stack *S);
/* Membuang semua makanan yang ada di nampan */

void COT(Stack *S);
/* Membuang satu bahan makanan yang ada di nampan */

void Order(int room, POINT P, TabInt *orders, TabInt *tables);
/* Mengambil order dari meja yang bersebelahan */

void AddRemove(TabInt *orders, Queue *Q, JAM J, ROOM *R, POINT P, int *life, TabInt *tables, int *Add, int money, int *custs);
/*Menambah/mengurangi array order, antrian, array table jika waktu tunggu sudah habis
  serat melaukan penambahan waktu */

void Recipe(BinTree P);
/*Mencetak Resep yang digunakan pada Engi's Kitchen */

/*FUNGSI PEMBANTU AMBIL BAHAN MAKANAN */
boolean IsPlateExist(Stack S);
/* Mengembalikan true apabila pada Stack Hand sudah terdapat piring */

void SearchBranch(BinTree *P, Stack * StackIn, Stack * StackOut);
/*FUNGSI PEMBANTU PUT */

void Put(BinTree P, Stack *Bahan, Stack *Food, POINT point, POINT N);
/* I.S P, Bahan, dan Food semuanya harus sudah terdefinisi */
/* Prosedur ini mengecek apakah urutan bahan dalam Stack sudah benar dari bawah ke atas */
/* Jika benar , F.S semua bahan berurutan yang sesuai dengan resep yang ada pada BinTree dihilangkan,*/
/* dan makanan jadi ditambahkan pada Stack Food */
/* Jika tidak ada urutan bahan yang benar, tidak merubah apa-apa pada stack bahan dan stack food*/

void Inisialisasi(int n, int *room, int *custs, ROOM *R, POINT *P, POINT *N, JAM *J, int *Add, Queue *Q, Stack *Hand, Stack *Food, TabInt *orders, TabInt *tables, TabInt *kitchen, StatusTable *emptyOrder, int *life, int *money, BinTree *Resep);
/*  Melakukan inisiaisasi state pada program bentuk setiap room yaitu ruangan dalam representasi matriks, 
    koordinat pemain, waktu pemain, antrian, stack of foods, stack of hand, arrayorders, arraytables, arraykitchen, dll */

void Give(int room, Stack *Food, ROOM *R, POINT P,TabInt *tables, TabInt *orders, int *money);
/*Memberikan makanan ke pengguna. Jika user sedang di sekitar meja dan pesanan sesuai maka
  pesanan akan diberikan dan uang akan bertambah*/

void LoadRoom (ROOM *R, TabInt *tables, TabInt *kitchen, POINT *N, StatusTable status);
/*Melakukan pembacaan yang berisi informasi mengenai bentuk ruangan untuk pertama kali
  Procedure ini akan dipanggil saat progra melakukan inisialisasi state*/

void SaveGame(char name[20], int room, int custs, POINT P, POINT N, JAM J, int Add, Queue Q, Stack Hand, Stack Food, TabInt orders, TabInt tables, TabInt kitchen, int life, int money);
/* Menyimpan semua informasi state game pada file eksternal */

void LoadGame(char name[20], int *room, int *custs, ROOM *R, POINT *P, POINT *N, JAM *J, int *Add, Queue *Q, Stack *Hand, Stack *Food, TabInt *orders, TabInt *tables, TabInt *kitchen, StatusTable *status, int *life, int *money, BinTree *Resep);
/*  Melakukan pembacaan state pada file dan melakukan load pada bentuk setiap room yaitu ruangan dalam representasi matriks, 
    koordinat pemain, waktu pemain, antrian, stack of foods, stack of hand, arrayorders, arraytables, arraykitchen, dll */